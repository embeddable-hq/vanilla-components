import{G as e,W as o}from"./p-1e3a059f.js";var a=(e=>(e.ASCENDING="Ascending",e.DESCENDING="Descending",e))(a||{});const i=e("sortDirection",{label:"Sort Direction",optionLabel:e=>e.value});o(i,{value:a.ASCENDING});o(i,{value:a.DESCENDING});export{i,a as n};
//# sourceMappingURL=p-3955e72b.js.map
