var l = function() {
  return l = Object.assign || function(r) {
    for (var i, e = 1, s = arguments.length; e < s; e++) {
      i = arguments[e];
      for (var o in i) Object.prototype.hasOwnProperty.call(i, o) && (r[o] = i[o]);
    }
    return r;
  }, l.apply(this, arguments);
};
var E = "en-US", t = function(n, r) {
  return r === void 0 && (r = {}), {
    __embeddableType: "built-in",
    toString: function() {
      return n;
    },
    typeConfig: l({ label: n, optionLabel: function() {
      return n;
    } }, r)
  };
}, u = function(n, r) {
  if (globalThis.__EMBEDDABLE__ = globalThis.__EMBEDDABLE__ || {}, globalThis.__EMBEDDABLE__.types = globalThis.__EMBEDDABLE__.types || {}, h.includes(n))
    throw new Error("Type ".concat(n, " is part of the nativeTpes and cannot be defined"), { cause: "sdk" });
  return globalThis.__EMBEDDABLE__.types[n] = l({ name: n }, r), {
    __embeddableType: "custom",
    toString: function() {
      return n;
    },
    typeConfig: r
  };
}, T = "string", v = "number", L = "boolean", b = "time", p = "timeRange", A = "granularity", m = "dataset", B = "measure", S = "dimension", M = "dimensionOrMeasure", h = [
  T,
  v,
  L,
  b,
  p,
  A,
  m,
  B,
  S,
  M
], a = function(n, r) {
  if (globalThis.__EMBEDDABLE__ = globalThis.__EMBEDDABLE__ || {}, typeof n == "string")
    globalThis.__EMBEDDABLE__.nativeTypes = globalThis.__EMBEDDABLE__.nativeTypes || {}, globalThis.__EMBEDDABLE__.nativeTypes[n] = globalThis.__EMBEDDABLE__.nativeTypes[n] || {}, globalThis.__EMBEDDABLE__.nativeTypes[n].options = globalThis.__EMBEDDABLE__.nativeTypes[n].options || [], globalThis.__EMBEDDABLE__.nativeTypes[n].options.push(r);
  else {
    var i = n.toString();
    if (!globalThis.__EMBEDDABLE__.types[i])
      return;
    globalThis.__EMBEDDABLE__.types[i].options = globalThis.__EMBEDDABLE__.types[i].options || [], globalThis.__EMBEDDABLE__.types[i].options.push(r);
  }
};
t("string", {
  transform: function(n) {
    return n;
  },
  optionLabel: function(n) {
    return Array.isArray(n) ? "[".concat(n.map(function(r) {
      return '"'.concat(r, '"');
    }).join(","), "]") : '"'.concat(n, '"');
  }
});
t("number", {
  transform: function(n) {
    return Array.isArray(n) ? n : n && Number(n);
  },
  optionLabel: function(n) {
    var r;
    return Array.isArray(n) ? "[".concat(n.join(","), "]") : (r = n == null ? void 0 : n.toLocaleString(E)) !== null && r !== void 0 ? r : "";
  }
});
t("boolean", {
  transform: function(n) {
    return n === "true" || n === !0;
  },
  optionLabel: function(n) {
    return n ? "true" : "false";
  }
});
t("time", {
  transform: function(n) {
    var r = n != null && n.date ? new Date(n.date) : void 0, i = r && r.toString() !== "Invalid Date";
    return {
      date: i ? r : void 0,
      relativeTimeString: n == null ? void 0 : n.relativeTimeString
    };
  },
  optionLabel: function(n) {
    var r, i;
    return n ? n != null && n.date ? (i = (r = n.date) === null || r === void 0 ? void 0 : r.toLocaleDateString(E)) !== null && i !== void 0 ? i : n.date.toLocaleString() : n.relativeTimeString : "";
  }
});
t("timeRange", {
  transform: function(n) {
    if (n) {
      var r = [n == null ? void 0 : n.from, n == null ? void 0 : n.to], i = r[0], e = r[1], s = new Date(i), o = new Date(e);
      return {
        from: s.toString() !== "Invalid Date" ? s : void 0,
        to: o.toString() !== "Invalid Date" ? o : void 0,
        relativeTimeString: n == null ? void 0 : n.relativeTimeString
      };
    }
  },
  optionLabel: function(n) {
    var r, i, e, s, o, d;
    return n ? n != null && n.from && (n != null && n.to) ? "".concat((i = (r = n.from) === null || r === void 0 ? void 0 : r.toLocaleDateString(E)) !== null && i !== void 0 ? i : (e = n.from) === null || e === void 0 ? void 0 : e.toLocaleString(), ",").concat((o = (s = n.to) === null || s === void 0 ? void 0 : s.toLocaleDateString(E)) !== null && o !== void 0 ? o : (d = n.to) === null || d === void 0 ? void 0 : d.toLocaleString()) : n == null ? void 0 : n.relativeTimeString : "";
  }
});
t("granularity", {
  transform: function(n) {
    return n;
  },
  optionLabel: function(n) {
    return n;
  }
});
t("dataset");
t("measure");
t("dimension");
t("dimensionOrMeasure");
var c = /* @__PURE__ */ ((n) => (n.NUMERIC_VALUES_ONLY = "Numeric Value Only", n.VALUE_BARS = "Value Bars", n.HEATMAP = "Heat Map", n))(c || {});
const D = u("metricsVisualizationFormat", {
  label: "Metrics visualization format",
  optionLabel: (n) => n.value
});
a(D, { value: c.NUMERIC_VALUES_ONLY });
a(D, { value: c.VALUE_BARS });
var f = /* @__PURE__ */ ((n) => (n.ASCENDING = "Ascending", n.DESCENDING = "Descending", n))(f || {});
const g = u("sortDirection", {
  label: "Sort Direction",
  optionLabel: (n) => n.value
});
a(g, { value: f.ASCENDING });
a(g, { value: f.DESCENDING });
const _ = u("timeComparison", {
  label: "Time Comparison",
  optionLabel: (n) => n
});
a(_, "No comparison");
a(_, "Previous period");
a(_, "Previous month");
a(_, "Previous quarter");
a(_, "Previous year");
