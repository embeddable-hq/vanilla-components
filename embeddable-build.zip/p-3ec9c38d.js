import{R as o}from"./p-b6189c95.js";import{_ as r}from"./p-d39d9511.js";import{w as m}from"./p-379ca809.js";const p=p=>o.jsx(r,{...p,className:"overflow-y-hidden",children:o.jsx(m,{...p})});export{p as n};
//# sourceMappingURL=p-3ec9c38d.js.map
