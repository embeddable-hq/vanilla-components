
globalThis.__EMBEDDABLE__ = globalThis.__EMBEDDABLE__ || {};
globalThis.__EMBEDDABLE__.editorsMeta = globalThis.__EMBEDDABLE__.editorsMeta || [
  
];
      